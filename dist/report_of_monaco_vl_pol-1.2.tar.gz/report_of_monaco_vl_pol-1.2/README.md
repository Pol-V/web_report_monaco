This script reads data from 3 files. 2 of them contain information with abbreviations of racers, their start and end time of best lap in Monaco race.
3-rd file contains information with abbreviation of racer, his name and team.
Script work with all this data and orders racers by time and print report that shows the top 15 racers and the rest after underline, for example:


1. Daniel Ricciardo      | RED BULL RACING TAG HEUER     | 1:12.013

2. Sebastian Vettel      | FERRARI                                            | 1:12.415

3. ...

------------------------------------------------------------------------

16. Brendon Hartley   | SCUDERIA TORO ROSSO HONDA | 1:13.179

17. Marcus Ericsson  | SAUBER FERRARI| 1:13.265



You can use CLI with this script and choose directory with files, which should be worked with. 
And you can choose order of sorting of the result of your code. 
E.g.
python report.py --files <folder_path> --order asc / --order desc

shows list of drivers and optional order (default order is asc)

Also you can get all information about one racer

python report.py --files <folder_path> --driver “Sebastian Vettel”  shows statistic about driver
