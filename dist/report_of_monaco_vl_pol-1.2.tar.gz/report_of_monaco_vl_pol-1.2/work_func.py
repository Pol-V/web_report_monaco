"""
You can use CLI with this code.
E.g.
> python work_func.py --files <folder_path> [--order asc | --order desc]  shows list of drivers and optional order (default order is asc)

> python work_func.py --files <folder_path> --driver “Sebastian Vettel”  shows statistic about driver

> python work_func.py --files drivers_data --order desc --driver "Fernando Alonso" shows statistic about driver with his position in list of racers
with chosen order of sorting

"""

from datetime import datetime
import argparse
import os
from typing import List


from exceptions import CustomError

BORDER_LINE_FOR_REPORT = 15


def make_dict_with_datetime_value(file):
    """Func takes file with data in such format SVF2018-05-24_12:02:58.917
    and returns dictionary with data about abbreviation of racer and his time of start or end of best lap.
    e.g {SVF': datetime.datetime(2018, 5, 24, 12, 2, 58, 917)}

    It's used with files which have information about time of beginnign and of end of best lap
    """
    file = {line[:3]: line[3:].strip() for line in file.readlines() if line != '\n'}
    res = {key: datetime(*map(int, ''.join([time if time.isdigit() else ' ' for time in values]).split())) for key, values
                 in file.items()}
    return res


def transform_abbreviations(file):
    """It takes file with data about drivers with next content in one line: DRR_Daniel Ricciardo_RED BULL RACING TAG HEUER
        DDR - it's abbreviation> which is used for marking driver
        Daniel Ricciardo - his name
        RED BULL RACING TAG HEUER - his team

        And returns dictionary with such values:
        'DRR': ['Daniel Ricciardo', 'RED BULL RACING TAG HEUER']
        key = abbreviation
        value[0] = name of racer
        value[1] = his team
        """
    data_about_drivers = {driver.split("_")[0]: driver.strip().split("_")[1:] for driver in file.readlines()}
    return data_about_drivers


def sort_dictionary_by_time(abbreviations):
    """"This func takes dictionary with such content:
       {Abbreviation: [name of racer, his team, his time of best lap]
       Func sorts dictionary by time-parameter.
   """
    try:
        res = {value[0]: value[1:] for value in abbreviations.values()}
        res = dict(sorted(res.items(), key=lambda x: x[1][1]))
        return res
    except IndexError:
        raise CustomError('''Please use dictionary with data in next format: 
        {Abbreviation: [name of racer, his team, his time of best lap]''')


def build_report(start_of_race, end_of_race, data_about_drivers):
    """This func takes 3 files with information about racers:
    1) file with time of the beginning of theit best lap
    2) file with time of the end of their best lap
    3) Data about racers - theirs names, teams and abbreviations.
     It returns dictionary sorted by the time with all information about drivers in next format
     {'Sebastian Vettel': ['FERRARI', datetime.timedelta(seconds=64, microseconds=999415)]}
     key = name
     value[0] = team
     value[1] = time
     """
    try:
        with open(start_of_race, "r") as start_of_race_file, open(end_of_race, "r") as end_of_race_file, open (data_about_drivers, "r") as data_about_drivers:
            start = make_dict_with_datetime_value(start_of_race_file)
            end = make_dict_with_datetime_value(end_of_race_file)
            data_about_drivers = transform_abbreviations(data_about_drivers)
            for element in data_about_drivers:
                data_about_drivers[element].append(abs(end[element] - start[element]))
            data_about_drivers = sort_dictionary_by_time(data_about_drivers)
            return data_about_drivers
    except TypeError:
        raise CustomError('''You should use 3 files. 
        "Start of race" with content like "SVF2018-05-24_12:02:58.917"
        "end_of_race with content like "SVF2018-05-24_12:02:58.917"
        "abbreviations" with content like "DRR_Daniel Ricciardo_RED BULL RACING TAG HEUER"
        ''')
    except ValueError:
        raise CustomError('''You should use 3 files. 
        "Start of race" with content like "SVF2018-05-24_12:02:58.917"
        "end_of_race with content like "SVF2018-05-24_12:02:58.917"
        "abbreviations" with content like "DRR_Daniel Ricciardo_RED BULL RACING TAG HEUER"
        ''')




def print_report(data):
    """This function takes result of work of function build_report and prints it in such format:
    1. Sebastian Vettel|FERRARI|0:01:04.999415
    After driver on 15-th place it writes long line:
    -------------------------------------------------- ----------------------
    And continues printing below it
      """
    for number, (key, value) in enumerate(data.items(), 1):
        name_of_driver = key
        team_of_driver = value[0]
        time_of_driver = value[1]
        if number==BORDER_LINE_FOR_REPORT:
            print((f'{number}. {name_of_driver}|{team_of_driver}|{time_of_driver}'))
            print('-------------------------------------------------- ----------------------')
        else:
            print((f'{number}. {name_of_driver}|{team_of_driver}|{time_of_driver}'))





if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('-f', '--files', help='Your files', required=True)
    parser.add_argument('--desc_order', help='reverse sorting', nargs='?', required=False)
    parser.add_argument('-d', '--driver', help='Name of driver', required=False)
    parser.add_argument('--order', help='type of sorting. "--order desc" means DESC order of sorting. "--order asc" means asc order. By default asc order is used', nargs='?', required=False)

    args = parser.parse_args()

    if args.files:
        path_dir: str = args.files
        content_dir: List[str] = os.listdir(path_dir)
        content_dir = [f'{args.files}/{name_of_file}' for name_of_file in content_dir]
        res = build_report(*content_dir)

        if args.order=='desc':
            res = {k: v for k, v in sorted(res.items(), reverse=True, key=lambda item: item[1][1])}

        if args.driver:
            driver = args.driver

            for number, (key, value) in enumerate(res.items(), 1):
                name_of_driver = key
                team_of_driver = value[0]
                time_of_driver = value[1]
                if key == driver:
                    print((f'{number}. {name_of_driver}|{team_of_driver}|{time_of_driver}'))
        else:
            print_report(res)

#
